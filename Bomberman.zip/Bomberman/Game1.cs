﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Microsoft.Xna.Framework.Audio;
using System.IO;

namespace Bomberman;

public enum TileType { Empty, Indestructible, Destructible }

public class Tile
{
    public TileType Type;
    public Rectangle Bounds;
}

public class Bomb
{
    public Point Cell;
    public float Timer;
    public int Range = 3;
    public Texture2D Texture;
    public float ExemptTime = 0f; // tiempo durante el cual el colocador puede salir de la celda
}

public class Explosion
{
    public List<Point> Cells = new List<Point>();
    public float Lifetime = 0.6f;
    public Point Origin;
}

public class Game1 : Game
{
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;

    // MAPA
    private Texture2D mapTexture;
    private int tileSize = 48;
    private Tile[,] tiles;
    private int cols, rows;

    // JUGADOR
    Texture2D playerTexture;
    Texture2D walkFront, walkBack, walkLeft, walkProfile, espaldaDiagonal;
    Texture2D[] deathTextures;
    Vector2 playerPosition;
    float playerSpeed = 140f; // píxeles por segundo
    int playerSize = 32;
    bool isDead = false;
    bool gameOver = false;
    float deathTimer = 0f;
    int deathFrame = 0;
    float deathFrameTime = 0.12f;

    // BOMBA/EXPLOSIONES
    Texture2D bombTexture;
    List<Bomb> bombs = new List<Bomb>();
    List<Explosion> explosions = new List<Explosion>();
    Texture2D explosionTexture;
    Texture2D explosionHorizontalTexture;
    Texture2D explosionVerticalTexture;
    SoundEffect explosionSfx;

    // ENEMIGOS
    Texture2D enemyTexture;
    Texture2D[] enemyDeathTextures;
    Texture2D doorTexture;
    Texture2D victoryBgTexture;
    Point doorCell;
    bool doorRevealed = false;
    int level = 1;
    const int maxLevel = 3;
    int doorCrossCount = 0;
    class Enemy { public Vector2 Pos; public Point Cell; public Vector2 Dir; public float Speed = 60f; public int Size = 64; public float TurnCooldown = 0f; }
    List<Enemy> enemies = new List<Enemy>();
    class EnemyDeath { public Vector2 Pos; public int Frame; public float Timer; }
    List<EnemyDeath> enemyDeaths = new List<EnemyDeath>();

    // Estado
    int score = 0;
    int maxBombs = 1;
    int lives = 3;
    // menus / estado global
    enum GameState { MainMenu, ConfigMenu, Playing, GameOver, Victory }
    GameState state = GameState.MainMenu;
    // no menu images: menus are drawn procedurally
    Texture2D hearts1, hearts2, hearts3;
    SpriteFont menuFont;
    float masterVolume = 0.5f; // 0..1
    bool draggingVolume = false;
    // brick texture (optional) — will stretch to tile cell when available
    Texture2D brickTexture;
    // (brick/explosion sprites reverted — drawing uses solid rectangles again when texture missing)
    // music
    Song menuSong;
    Song playingSong;
    Song currentSong = null;
    Song explosionSong;
    float explosionSongTimer = 0f;
    Song pendingResumeSong = null;
    float victoryIgnoreTimer = 0f;
    float exitSuppressedTimer = 0f;
    // Level transition overlay
    bool isLevelTransition = false;
    float levelTransitionTimer = 0f;
    int upcomingLevel = 1;
    GameState prevState;
    bool isPaused = false;

    Random rnd = new Random();
    Vector2 lastMoveDirection = Vector2.Zero;
    Point previousPlayerCell = Point.Zero;
    KeyboardState prevKeyboardState;
    GamePadState prevGamepadState;
    Microsoft.Xna.Framework.Input.MouseState prevMouseState;
    int menuIndex = 0;

    // simple file logger to capture events even if console is not visible
    string debugLogPath => Path.Combine(AppDomain.CurrentDomain.BaseDirectory ?? ".", "game_debug.log");
    void LogToFile(string msg)
    {
        try { File.AppendAllText(debugLogPath, DateTime.Now.ToString("o") + " " + msg + Environment.NewLine); } catch { }
    }
    // logical options (we won't draw these strings over the image; they are for logic only)
    string[] mainMenuOptions = new[] { "Jugar", "Configuracion", "Salir" };
    string[] gameOverOptions = new[] { "Volver a jugar", "Abandonar el juego" };
    bool showMenuHotspots = false; // toggle with F1 to visualize clickable areas
    string[] victoryOptions = new[] { "Jugar de nuevo", "Volver al menu", "Salir del juego" };

    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
    }

    protected override void Initialize()
    {
        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);

        Texture2D TryLoad(params string[] keys)
        {
            foreach (var k in keys)
            {
                try { return Content.Load<Texture2D>(k); } catch { }
            }
            return null;
        }

        mapTexture = Content.Load<Texture2D>("Mapa/Mapa");
        // (no longer loading brick/explosion sprites; drawing uses solid rectangles)
        hearts1 = Content.Load<Texture2D>("Sprites/1corazon");
        hearts2 = Content.Load<Texture2D>("Sprites/2corazones");
        hearts3 = Content.Load<Texture2D>("Sprites/3corazones");
        menuFont = Content.Load<SpriteFont>("Fonts/MenuFont");
        playerTexture = Content.Load<Texture2D>("Sprites/Bomberdefrente");
        bombTexture = Content.Load<Texture2D>("Sprites/bomba");
        // caminar/direcciones
        walkFront = Content.Load<Texture2D>("Sprites/CaminandoFrente");
        walkBack = Content.Load<Texture2D>("Sprites/CaminandoEspalda");
        walkLeft = Content.Load<Texture2D>("Sprites/CaminandoParaElOtroLado");
        walkProfile = Content.Load<Texture2D>("Sprites/CaminandoPerfil");
        espaldaDiagonal = Content.Load<Texture2D>("Sprites/EspaldaDiagonal");
        // muerte frames (Muerte1..Muerte7)
        deathTextures = new Texture2D[7];
        for (int i = 0; i < 7; i++) deathTextures[i] = Content.Load<Texture2D>($"Sprites/Muerte{i+1}");
        // enemigo
        enemyTexture = Content.Load<Texture2D>("Sprites/enemigo");
        enemyDeathTextures = new Texture2D[2];
        enemyDeathTextures[0] = Content.Load<Texture2D>("Sprites/muerteenemigo1");
        enemyDeathTextures[1] = Content.Load<Texture2D>("Sprites/muertenemigo2");
        doorTexture = Content.Load<Texture2D>("Sprites/puerta");

        // explosion sprites (center, horizontal, vertical) - try multiple keys if needed
        explosionTexture = TryLoad("Sprites/explosionprincipal", "Sprites/explosion", "explosionprincipal", "explosion");
        explosionHorizontalTexture = TryLoad("Sprites/explosionhorizontal", "explosionhorizontal", "Sprites/explosion_horizontal");
        explosionVerticalTexture = TryLoad("Sprites/explosionvertical", "explosionvertical", "Sprites/explosion_vertical");
        // explosion sound effect (optional)
        try { explosionSfx = Content.Load<SoundEffect>("Efectos/explosion"); } catch { explosionSfx = null; }
        // also try loading an explosion Song (fallback to the MP3 file if SFX not available)
        try { explosionSong = Content.Load<Song>("Efectos/explosion"); } catch { explosionSong = null; }

        // load music
        try {
            menuSong = Content.Load<Song>("Musica/The search (online-audio-converter.com)");
        } catch { menuSong = null; }
        try {
            playingSong = Content.Load<Song>("Musica/Run As Fast As You Can (online-audio-converter.com)");
        } catch { playingSong = null; }
        // brick texture (optional). Try a few keys
        brickTexture = TryLoad("Sprites/pared", "pared", "Sprites/ladrillo", "ladrillo");
        // victory/background image (if provided)
        victoryBgTexture = TryLoad("Menu/Victory", "Menu/Victoria", "Menu/pixil-frame-0", "Menu/pixil-frame-0.png");
        MediaPlayer.Volume = masterVolume;
        MediaPlayer.IsRepeating = true;
        // start menu music by default
        if (menuSong != null) { MediaPlayer.Play(menuSong); currentSong = menuSong; }

        // Crear mapa en base al tamaño de la ventana
        cols = Math.Max(8, GraphicsDevice.Viewport.Width / tileSize);
        rows = Math.Max(6, GraphicsDevice.Viewport.Height / tileSize);
        tiles = new Tile[cols, rows];

        for (int x = 0; x < cols; x++)
        for (int y = 0; y < rows; y++)
        {
            tiles[x, y] = new Tile { Type = TileType.Empty, Bounds = new Rectangle(x * tileSize, y * tileSize, tileSize, tileSize) };
        }

        // Bordes indestructibles
        for (int x = 0; x < cols; x++) { tiles[x, 0].Type = TileType.Indestructible; tiles[x, rows - 1].Type = TileType.Indestructible; }
        for (int y = 0; y < rows; y++) { tiles[0, y].Type = TileType.Indestructible; tiles[cols - 1, y].Type = TileType.Indestructible; }

        // Patrón de paredes indestructibles en malla
        for (int x = 2; x < cols - 2; x += 2)
            for (int y = 2; y < rows - 2; y += 2)
                tiles[x, y].Type = TileType.Indestructible;

        // Bloques destructibles aleatorios evitando spawn (0,0) y sus vecinos
        for (int x = 1; x < cols - 1; x++)
        for (int y = 1; y < rows - 1; y++)
        {
            if (tiles[x, y].Type != TileType.Empty) continue;
            bool nearSpawn = (x <= 2 && y <= 2); // zona segura superior izquierda
            if (!nearSpawn && rnd.NextDouble() < 0.55)
                tiles[x, y].Type = TileType.Destructible;
        }

        // elegir una celda con bloque destructible para ocultar la puerta
        doorRevealed = false;
        var destructibles = new List<Point>();
        for (int x = 1; x < cols - 1; x++)
        for (int y = 1; y < rows - 1; y++)
            if (tiles[x, y].Type == TileType.Destructible && !(x <= 2 && y <= 2)) destructibles.Add(new Point(x, y));
        if (destructibles.Count > 0) doorCell = destructibles[rnd.Next(destructibles.Count)];
        else doorCell = new Point(Math.Min(3, cols-2), Math.Min(3, rows-2));

        // Posicionar jugador en la esquina superior izquierda (centrado en celda)
        playerPosition = new Vector2(tileSize * 1 + (tileSize - playerSize) / 2, tileSize * 1 + (tileSize - playerSize) / 2);

        // Spawn enemies in celdas vacías aleatorias (cantidad depende del nivel)
        int baseEnemies = 3 + (level - 1) * 2;
        for (int i = 0; i < baseEnemies; i++)
        {
            Point c;
            int attempts = 0;
            do
            {
                c = new Point(rnd.Next(1, cols - 1), rnd.Next(1, rows - 1));
                attempts++;
            } while ((tiles[c.X, c.Y].Type != TileType.Empty || (c.X <= 2 && c.Y <= 2)) && attempts < 200);
            var en = new Enemy();
            en.Cell = c;
            // use tile-aligned size so enemies fit cells and can move reliably
            en.Size = tileSize;
            en.Pos = new Vector2(c.X * tileSize, c.Y * tileSize);
            // small random start offset so they don't all overlap exactly
            en.Pos += new Vector2(0,0);
            // add small per-enemy randomness for direction changes
            // store change timer in Dir.W (abuse) and change interval encoded in Cell.X negative? Instead, we will use rnd in update
            en.Dir = RandomDir();
            enemies.Add(en);
        }
    }

    protected override void Update(GameTime gameTime)
    {
        try
        {
            try { LogToFile($"Update START state={state} prevState={prevState} exitSuppressed={exitSuppressedTimer} doorCross={doorCrossCount}"); } catch {}

        var keyboard = Keyboard.GetState();
        var gamepad = GamePad.GetState(PlayerIndex.One);

        // Exit only from MainMenu with edge-detected Escape to avoid accidental exit on state changes
        if (keyboard.IsKeyDown(Keys.Escape) && !prevKeyboardState.IsKeyDown(Keys.Escape) && state == GameState.MainMenu) { RequestExit("MainMenu_Escape"); }

        float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

        // Menú principal: responder a pulsaciones (edge) y mouse
        if (state == GameState.MainMenu)
        {
            var mouse = Microsoft.Xna.Framework.Input.Mouse.GetState();

            // toggle hotspot visualization
            if (keyboard.IsKeyDown(Keys.F1) && !prevKeyboardState.IsKeyDown(Keys.F1)) showMenuHotspots = !showMenuHotspots;

            // navigation: up/down via keyboard or gamepad
            bool up = (keyboard.IsKeyDown(Keys.Up) && !prevKeyboardState.IsKeyDown(Keys.Up)) || (gamepad.DPad.Up == ButtonState.Pressed && prevGamepadState.DPad.Up == ButtonState.Released) || (gamepad.ThumbSticks.Left.Y > 0.6f && prevGamepadState.ThumbSticks.Left.Y <= 0.6f);
            bool down = (keyboard.IsKeyDown(Keys.Down) && !prevKeyboardState.IsKeyDown(Keys.Down)) || (gamepad.DPad.Down == ButtonState.Pressed && prevGamepadState.DPad.Down == ButtonState.Released) || (gamepad.ThumbSticks.Left.Y < -0.6f && prevGamepadState.ThumbSticks.Left.Y >= -0.6f);
            if (up) { menuIndex = (menuIndex - 1 + mainMenuOptions.Length) % mainMenuOptions.Length; }
            if (down) { menuIndex = (menuIndex + 1) % mainMenuOptions.Length; }

            // Determine activation: keyboard/gamepad select or mouse click on specific button area
            int? activatedIndex = null;
            bool selectKey = (keyboard.IsKeyDown(Keys.Enter) && !prevKeyboardState.IsKeyDown(Keys.Enter)) || (keyboard.IsKeyDown(Keys.Space) && !prevKeyboardState.IsKeyDown(Keys.Space)) || (gamepad.IsButtonDown(Buttons.Start) && !prevGamepadState.IsButtonDown(Buttons.Start));
            if (selectKey) activatedIndex = menuIndex;

            // mouse hover/click over option rectangles (these should match positions of the words in the menu image)
            var mainRects = GetMainMenuRects();
            for (int i = 0; i < mainRects.Length; i++)
            {
                var r = mainRects[i];
                if (r.Contains(mouse.Position)) menuIndex = i;
                if (mouse.LeftButton == ButtonState.Pressed && prevMouseState.LeftButton == ButtonState.Released && r.Contains(mouse.Position))
                {
                    activatedIndex = i; // mouse click determines exact option
                }
            }

            if (activatedIndex.HasValue)
            {
                int sel = activatedIndex.Value;
                if (sel == 0)
                {
                    level = 1; lives = 3; score = 0;
                    bombs.Clear(); explosions.Clear(); enemies.Clear(); enemyDeaths.Clear();
                    isDead = false; gameOver = false;
                    state = GameState.Playing; menuIndex = 0;
                    Restart();
                }
                else if (sel == 1)
                {
                    // abrir menú de configuración
                    state = GameState.ConfigMenu; menuIndex = 0;
                }
                else if (sel == 2)
                {
                    RequestExit("MainMenu_Option_Exit");
                }
            }

            prevKeyboardState = keyboard; prevGamepadState = gamepad; prevMouseState = mouse;
            base.Update(gameTime);
            return;
        }

            // Pantalla de Victoria (GANASTE)
            if (state == GameState.Victory)
            {
                var mouse = Microsoft.Xna.Framework.Input.Mouse.GetState();
                // decrement ignore timer to prevent accidental immediate activation
                if (victoryIgnoreTimer > 0f) victoryIgnoreTimer = Math.Max(0f, victoryIgnoreTimer - deltaTime);

                // navigation: up/down
                bool up = (keyboard.IsKeyDown(Keys.Up) && !prevKeyboardState.IsKeyDown(Keys.Up)) || (gamepad.DPad.Up == ButtonState.Pressed && prevGamepadState.DPad.Up == ButtonState.Released);
                bool down = (keyboard.IsKeyDown(Keys.Down) && !prevKeyboardState.IsKeyDown(Keys.Down)) || (gamepad.DPad.Down == ButtonState.Pressed && prevGamepadState.DPad.Down == ButtonState.Released);
                if (up) { menuIndex = (menuIndex - 1 + victoryOptions.Length) % victoryOptions.Length; }
                if (down) { menuIndex = (menuIndex + 1) % victoryOptions.Length; }

                int? activatedIndex = null;
                bool selectKey = false;
                if (victoryIgnoreTimer <= 0f)
                {
                    selectKey = (keyboard.IsKeyDown(Keys.Enter) && !prevKeyboardState.IsKeyDown(Keys.Enter)) || (keyboard.IsKeyDown(Keys.Space) && !prevKeyboardState.IsKeyDown(Keys.Space)) || (gamepad.IsButtonDown(Buttons.Start) && !prevGamepadState.IsButtonDown(Buttons.Start));
                    if (selectKey) activatedIndex = menuIndex;
                }

                // mouse hover/click
                int cxv = GraphicsDevice.Viewport.Width / 2;
                int cyv = GraphicsDevice.Viewport.Height / 2;
                int optWv = 360; int optHv = 56; int spacingv = 64;
                for (int i = 0; i < victoryOptions.Length; i++)
                {
                    var r = new Rectangle(cxv - optWv/2, cyv + i * spacingv, optWv, optHv);
                    if (r.Contains(mouse.Position)) menuIndex = i;
                    if (mouse.LeftButton == ButtonState.Pressed && prevMouseState.LeftButton == ButtonState.Released && r.Contains(mouse.Position)) activatedIndex = i;
                }

                if (activatedIndex.HasValue)
                {
                    int sel = activatedIndex.Value;
                    if (sel == 0)
                    {
                        // Jugar de nuevo: reiniciar juego al nivel 1
                        level = 1; lives = 3; score = 0;
                        bombs.Clear(); explosions.Clear(); enemies.Clear(); enemyDeaths.Clear();
                        isDead = false; gameOver = false;
                        state = GameState.Playing; menuIndex = 0;
                        Restart();
                    }
                    else if (sel == 1)
                    {
                        // Volver al menu
                        state = GameState.MainMenu; menuIndex = 0;
                    }
                    else if (sel == 2)
                    {
                        // Salir
                        RequestExit("Victory_Option_Exit");
                    }
                }

                prevKeyboardState = keyboard; prevGamepadState = gamepad; prevMouseState = mouse;
                base.Update(gameTime);
                return;
            }

        // Pantalla de Game Over
        if (state == GameState.GameOver)
        {
            var mouse = Microsoft.Xna.Framework.Input.Mouse.GetState();

            // navigation: up/down
            bool up = (keyboard.IsKeyDown(Keys.Up) && !prevKeyboardState.IsKeyDown(Keys.Up)) || (gamepad.DPad.Up == ButtonState.Pressed && prevGamepadState.DPad.Up == ButtonState.Released) || (gamepad.ThumbSticks.Left.Y > 0.6f && prevGamepadState.ThumbSticks.Left.Y <= 0.6f);
            bool down = (keyboard.IsKeyDown(Keys.Down) && !prevKeyboardState.IsKeyDown(Keys.Down)) || (gamepad.DPad.Down == ButtonState.Pressed && prevGamepadState.DPad.Down == ButtonState.Released) || (gamepad.ThumbSticks.Left.Y < -0.6f && prevGamepadState.ThumbSticks.Left.Y >= -0.6f);
            if (up) { menuIndex = (menuIndex - 1 + gameOverOptions.Length) % gameOverOptions.Length; }
            if (down) { menuIndex = (menuIndex + 1) % gameOverOptions.Length; }

            int? activatedIndex = null;
            bool selectKey = (keyboard.IsKeyDown(Keys.Enter) && !prevKeyboardState.IsKeyDown(Keys.Enter)) || (keyboard.IsKeyDown(Keys.Space) && !prevKeyboardState.IsKeyDown(Keys.Space)) || (gamepad.IsButtonDown(Buttons.Start) && !prevGamepadState.IsButtonDown(Buttons.Start));
            if (selectKey) activatedIndex = menuIndex;

            // mouse hover/click
            int cx = GraphicsDevice.Viewport.Width / 2;
            int cy = GraphicsDevice.Viewport.Height / 2;
            int optW = 300; int optH = 48; int spacing = 56;
            for (int i = 0; i < gameOverOptions.Length; i++)
            {
                var r = new Rectangle(cx - optW/2, cy + i * spacing, optW, optH);
                if (r.Contains(mouse.Position)) menuIndex = i;
                if (mouse.LeftButton == ButtonState.Pressed && prevMouseState.LeftButton == ButtonState.Released && r.Contains(mouse.Position))
                {
                    activatedIndex = i;
                }
            }

            if (activatedIndex.HasValue)
            {
                int sel = activatedIndex.Value;
                if (sel == 0)
                {
                    level = 1; lives = 3; score = 0;
                    bombs.Clear(); explosions.Clear(); enemies.Clear(); enemyDeaths.Clear();
                    isDead = false; gameOver = false;
                    state = GameState.Playing; menuIndex = 0;
                    Restart();
                }
                else if (sel == 1)
                {
                    RequestExit("GameOver_Option_Exit");
                }
            }

            prevKeyboardState = keyboard; prevGamepadState = gamepad; prevMouseState = mouse;
            base.Update(gameTime);
            return;
        }

        // Menú de Configuración con control de volumen
        if (state == GameState.ConfigMenu)
        {
            var mouse = Microsoft.Xna.Framework.Input.Mouse.GetState();
            // options: Volumen (interactive), Volver, Salir
            string[] cfgOptions = new[] { "Volumen", "Volver", "Salir" };
            // navigate up/down between items (Volumen is index 0)
            bool up = (keyboard.IsKeyDown(Keys.Up) && !prevKeyboardState.IsKeyDown(Keys.Up));
            bool down = (keyboard.IsKeyDown(Keys.Down) && !prevKeyboardState.IsKeyDown(Keys.Down));
            if (up) menuIndex = (menuIndex - 1 + cfgOptions.Length) % cfgOptions.Length;
            if (down) menuIndex = (menuIndex + 1) % cfgOptions.Length;

            int? activatedIndex = null;
            bool selectKey = (keyboard.IsKeyDown(Keys.Enter) && !prevKeyboardState.IsKeyDown(Keys.Enter)) || (keyboard.IsKeyDown(Keys.Space) && !prevKeyboardState.IsKeyDown(Keys.Space));
            if (selectKey && menuIndex != 0) activatedIndex = menuIndex;

            // slider rect
            int panelCx = GraphicsDevice.Viewport.Width / 2;
            int panelCy = GraphicsDevice.Viewport.Height / 2;
            Rectangle sliderRect = new Rectangle(panelCx - 160, panelCy - 40, 320, 20);
            // knob position
            int knobX = sliderRect.Left + (int)(masterVolume * (sliderRect.Width));
            Rectangle knobRect = new Rectangle(knobX - 8, sliderRect.Top - 6, 16, sliderRect.Height + 12);

            // mouse interactions: start/stop dragging
            if (mouse.LeftButton == ButtonState.Pressed && prevMouseState.LeftButton == ButtonState.Released)
            {
                if (knobRect.Contains(mouse.Position) || sliderRect.Contains(mouse.Position)) draggingVolume = true;
                else
                {
                    // check clicks on other options
                    int optW = 300; int optH = 48; int spacing = 56;
                    for (int i = 0; i < cfgOptions.Length; i++)
                    {
                        var r = new Rectangle(panelCx - optW/2, panelCy + i * spacing, optW, optH);
                        if (r.Contains(mouse.Position)) activatedIndex = i;
                    }
                }
            }
            if (mouse.LeftButton == ButtonState.Released && prevMouseState.LeftButton == ButtonState.Pressed) draggingVolume = false;

            // dragging or keyboard left/right to change volume
            if (draggingVolume)
            {
                float t = (mouse.X - sliderRect.Left) / (float)sliderRect.Width;
                masterVolume = Math.Clamp(t, 0f, 1f);
                MediaPlayer.Volume = masterVolume;
            }
            else if (menuIndex == 0)
            {
                if (keyboard.IsKeyDown(Keys.Left) && !prevKeyboardState.IsKeyDown(Keys.Left)) masterVolume = Math.Clamp(masterVolume - 0.05f, 0f, 1f);
                if (keyboard.IsKeyDown(Keys.Right) && !prevKeyboardState.IsKeyDown(Keys.Right)) masterVolume = Math.Clamp(masterVolume + 0.05f, 0f, 1f);
                MediaPlayer.Volume = masterVolume;
            }

            // numeric adjustments via gamepad
            if (menuIndex == 0)
            {
                if (gamepad.ThumbSticks.Left.X < -0.5f && prevGamepadState.ThumbSticks.Left.X >= -0.5f) masterVolume = Math.Clamp(masterVolume - 0.05f, 0f, 1f);
                if (gamepad.ThumbSticks.Left.X > 0.5f && prevGamepadState.ThumbSticks.Left.X <= 0.5f) masterVolume = Math.Clamp(masterVolume + 0.05f, 0f, 1f);
                MediaPlayer.Volume = masterVolume;
            }

            // handle activated options (Volver/Salir)
            if (activatedIndex.HasValue)
            {
                int sel = activatedIndex.Value;
                if (sel == 1) { state = GameState.MainMenu; menuIndex = 0; }
                else if (sel == 2) { RequestExit("Config_Option_Exit"); }
            }

            prevKeyboardState = keyboard; prevGamepadState = gamepad; prevMouseState = mouse;
            base.Update(gameTime);
            return;
        }

        // Pause toggle during gameplay (edge-detected). Consume the press immediately to avoid double-toggle.
        if (state == GameState.Playing && keyboard.IsKeyDown(Keys.Escape) && !prevKeyboardState.IsKeyDown(Keys.Escape))
        {
            isPaused = !isPaused;
            // consume input so the same press won't be seen again by other handlers
            prevKeyboardState = keyboard; prevGamepadState = gamepad; prevMouseState = Microsoft.Xna.Framework.Input.Mouse.GetState();
        }
        if (state == GameState.Playing && isPaused)
        {
            // when paused, skip gameplay updates (prev states will be updated before returning later)
            prevKeyboardState = keyboard; prevGamepadState = gamepad; prevMouseState = Microsoft.Xna.Framework.Input.Mouse.GetState();
            base.Update(gameTime);
            return;
        }

        Vector2 move = Vector2.Zero;
        if (keyboard.IsKeyDown(Keys.W) || keyboard.IsKeyDown(Keys.Up) || gamepad.ThumbSticks.Left.Y > 0.2f) move.Y = -1;
        if (keyboard.IsKeyDown(Keys.S) || keyboard.IsKeyDown(Keys.Down) || gamepad.ThumbSticks.Left.Y < -0.2f) move.Y = 1;
        if (keyboard.IsKeyDown(Keys.A) || keyboard.IsKeyDown(Keys.Left) || gamepad.ThumbSticks.Left.X < -0.2f) move.X = -1;
        if (keyboard.IsKeyDown(Keys.D) || keyboard.IsKeyDown(Keys.Right) || gamepad.ThumbSticks.Left.X > 0.2f) move.X = 1;

        if (move.LengthSquared() > 0) move.Normalize();

        // Si está muerto, actualizar animación de muerte / respawn
        if (isDead)
        {
            deathTimer += deltaTime;
            if (deathTimer >= deathFrameTime)
            {
                deathTimer = 0f;
                deathFrame++;
            }

            if (deathFrame >= deathTextures.Length)
            {
                // terminado animación de muerte
                if (lives > 0)
                {
                    // respawn
                    isDead = false;
                    deathFrame = 0;
                    deathTimer = 0f;
                    // reposicionar jugador en spawn
                    playerPosition = new Vector2(tileSize * 1 + (tileSize - playerSize) / 2, tileSize * 1 + (tileSize - playerSize) / 2);
                    // limpiar bombas/ explosiones para evitar muerte instantanea
                    bombs.Clear();
                    explosions.Clear();
                }
                else
                {
                    // pasar a pantalla de game over
                    state = GameState.GameOver;
                    isDead = false;
                }
            }

            base.Update(gameTime);
            return;
        }

        // store previous player center cell (used to allow exiting bomb cell)
        previousPlayerCell = new Point((int)(playerPosition.X + playerSize/2) / tileSize, (int)(playerPosition.Y + playerSize/2) / tileSize);

        // Movimiento con colisiones por ejes (tile-based collision check)
        Vector2 next = playerPosition;
        // mover X
        next.X += move.X * playerSpeed * deltaTime;
        if (!IsColliding(next)) { playerPosition.X = next.X; if (move.X != 0) lastMoveDirection = new Vector2(move.X, 0); }
        // mover Y
        next = playerPosition;
        next.Y += move.Y * playerSpeed * deltaTime;
        if (!IsColliding(next)) { playerPosition.Y = next.Y; if (move.Y != 0) lastMoveDirection = new Vector2(0, move.Y); }

        // Colocar bomba con espacio (se usa IsKeyDown simple; no auto edge)
        if ((keyboard.IsKeyDown(Keys.Space) || gamepad.IsButtonDown(Buttons.A)) && CanPlaceBomb())
        {
            PlaceBombAtPlayer();
        }

        // Actualizar bombas
        for (int i = bombs.Count - 1; i >= 0; i--)
        {
            bombs[i].Timer -= deltaTime;
            // decrementar tiempo de exención si lo tiene
            if (bombs[i].ExemptTime > 0f) bombs[i].ExemptTime -= deltaTime;
            if (bombs[i].Timer <= 0)
            {
                Explode(bombs[i]);
                bombs.RemoveAt(i);
            }
        }

        // Actualizar explosiones
        for (int i = explosions.Count - 1; i >= 0; i--)
        {
            explosions[i].Lifetime -= deltaTime;
            if (explosions[i].Lifetime <= 0) explosions.RemoveAt(i);
        }

        // Actualizar enemigos
        for (int i = enemies.Count - 1; i >= 0; i--)
        {
            var e = enemies[i];
            // decrementar cooldown
            if (e.TurnCooldown > 0f) e.TurnCooldown -= deltaTime;
            // ocasionalmente cambiar dirección aleatoriamente para explorar el mapa
            if (e.TurnCooldown <= 0f && rnd.NextDouble() < 0.03) { e.Dir = RandomDir(); e.TurnCooldown = 0.4f; }

            // mover
            e.Pos += e.Dir * e.Speed * deltaTime;
            // actualizar celda
            e.Cell = new Point((int)(e.Pos.X + e.Size/2) / tileSize, (int)(e.Pos.Y + e.Size/2) / tileSize);
            // colisiones con tiles
            if (IsEnemyColliding(e))
            {
                // retroceder y elegir nueva dirección
                e.Pos -= e.Dir * e.Speed * deltaTime * 1.2f;
                e.Dir = RandomDir();
                e.TurnCooldown = 0.4f;
                // snap enemy to center of its current cell to avoid getting stuck
                e.Cell = new Point((int)(e.Pos.X + e.Size/2) / tileSize, (int)(e.Pos.Y + e.Size/2) / tileSize);
                e.Pos = new Vector2(e.Cell.X * tileSize + (tileSize - e.Size) / 2, e.Cell.Y * tileSize + (tileSize - e.Size) / 2);
            }

            // colisión con jugador: usar distancia para evitar matar a distancia demasiado lejana
            Vector2 playerCenter = playerPosition + new Vector2(playerSize / 2f, playerSize / 2f);
            Vector2 enemyCenter = e.Pos + new Vector2(e.Size / 2f, e.Size / 2f);
            float attackRadius = tileSize * 0.55f; // ajuste: rango de daño del enemigo
            if (Vector2.Distance(playerCenter, enemyCenter) < attackRadius)
            {
                isDead = true;
                deathFrame = 0;
                deathTimer = 0f;
                lives = Math.Max(0, lives - 1);
                score = Math.Max(0, score - 50);
                // do not remove enemy; continue to next
                continue;
            }

            // si en explosión, morir - reproducir animación de muerte de enemigo
            bool dead = false;
            foreach (var ex in explosions) foreach (var c in ex.Cells) if (c == e.Cell) dead = true;
            if (dead)
            {
                enemyDeaths.Add(new EnemyDeath { Pos = e.Pos, Frame = 0, Timer = 0f });
                enemies.RemoveAt(i);
                score += 50;
                continue;
            }
        }

        // Actualizar animaciones de muerte de enemigos
        for (int i = enemyDeaths.Count - 1; i >= 0; i--)
        {
            var ed = enemyDeaths[i];
            ed.Timer += deltaTime;
            if (ed.Timer > 0.25f)
            {
                ed.Frame++;
                ed.Timer = 0f;
            }
            if (ed.Frame >= enemyDeathTextures.Length) enemyDeaths.RemoveAt(i);
        }

        // Actualizar título con estado rápido (incluye vidas)
        try { Window.Title = $"Score:{score} Lives:{lives} Bombs:{maxBombs - bombs.Count} Pos:{playerPosition.X:0},{playerPosition.Y:0}"; } catch {}
        // Si puerta revelada y jugador en la celda de la puerta -> avanzar nivel o ganar
        Point playerCellNow = new Point((int)(playerPosition.X + playerSize/2) / tileSize, (int)(playerPosition.Y + playerSize/2) / tileSize);
        if (doorRevealed && playerCellNow == doorCell && enemies.Count == 0)
        {
            // only count when the player *entered* the door cell this frame
            if (previousPlayerCell != doorCell)
            {
                doorCrossCount++;
            try { Console.WriteLine($"DOOR_CROSS count={doorCrossCount}"); } catch { }
            try { LogToFile($"DOOR_CROSS count={doorCrossCount}"); } catch {}

                if (doorCrossCount >= 3)
                {
                    // reached required crossings -> Victory
                    try { Console.WriteLine($"ENTER_VICTORY playerCell={playerCellNow} doorCell={doorCell} enemies={enemies.Count} doorCrossCount={doorCrossCount}"); } catch { }
                    try { LogToFile($"ENTER_VICTORY playerCell={playerCellNow} doorCell={doorCell} enemies={enemies.Count} doorCrossCount={doorCrossCount}"); } catch {}
                    state = GameState.Victory;
                    // stop gameplay music
                    gameOver = false;
                    // consume current input so the victory menu doesn't immediately activate an option
                    prevKeyboardState = Keyboard.GetState();
                    prevGamepadState = GamePad.GetState(PlayerIndex.One);
                    prevMouseState = Microsoft.Xna.Framework.Input.Mouse.GetState();
                    menuIndex = 0;
                    isPaused = false;
                    // ignore input for a short moment to avoid accidental activation/exit
                    victoryIgnoreTimer = 0.25f;
                    exitSuppressedTimer = 0.5f;
                    try { LogToFile("Transitioned to Victory state and returning from Update"); } catch {}
                    return;
                }
                else
                {
                    // advance level if possible, otherwise rebuild the same level
                    if (level < maxLevel) level++;
                    bombs.Clear(); explosions.Clear(); enemies.Clear(); enemyDeaths.Clear();
                    Restart();
                }
            }
        }

        // handle music changes when state changes
        if (state != prevState)
        {
            if (state == GameState.MainMenu)
            {
                if (menuSong != null && currentSong != menuSong) { MediaPlayer.Play(menuSong); currentSong = menuSong; }
            }
            else if (state == GameState.Playing)
            {
                if (playingSong != null && currentSong != playingSong) { MediaPlayer.Play(playingSong); currentSong = playingSong; }
            }
            else if (state == GameState.GameOver)
            {
                // stop music on game over
                MediaPlayer.Stop(); currentSong = null;
            }
            else if (state == GameState.Victory)
            {
                // stop music on victory
                MediaPlayer.Stop(); currentSong = null;
            }
            else if (state == GameState.ConfigMenu)
            {
                // keep menu music while in config
                if (menuSong != null && currentSong != menuSong) { MediaPlayer.Play(menuSong); currentSong = menuSong; }
            }
            prevState = state;
        }

        // handle short explosion-song fallback timer (resume previous music)
        if (explosionSongTimer > 0f)
        {
            explosionSongTimer -= deltaTime;
            if (explosionSongTimer <= 0f)
            {
                if (pendingResumeSong != null)
                {
                    try { MediaPlayer.Play(pendingResumeSong); currentSong = pendingResumeSong; } catch { }
                    pendingResumeSong = null;
                }
                explosionSongTimer = 0f;
            }
        }

        // decrement exit suppression timer (used to prevent immediate Exit after entering Victory)
        if (exitSuppressedTimer > 0f) exitSuppressedTimer = Math.Max(0f, exitSuppressedTimer - deltaTime);

        // update previous input states for reliable edge detection next frame
        prevKeyboardState = Keyboard.GetState();
        prevGamepadState = GamePad.GetState(PlayerIndex.One);
        prevMouseState = Microsoft.Xna.Framework.Input.Mouse.GetState();

        base.Update(gameTime);
        }
        catch (Exception ex)
        {
            try { LogToFile($"Exception in Update: {ex}"); } catch { }
            throw;
        }
    }

    Vector2 RandomDir()
    {
        // devuelve una dirección cardinal aleatoria
        int r = rnd.Next(4);
        return r switch
        {
            0 => new Vector2(1,0),
            1 => new Vector2(-1,0),
            2 => new Vector2(0,1),
            _ => new Vector2(0,-1),
        };
    }

    bool IsEnemyColliding(Enemy e)
    {
        Rectangle rect = new Rectangle((int)e.Pos.X, (int)e.Pos.Y, e.Size, e.Size);
        int left = Math.Clamp(rect.Left / tileSize, 0, cols - 1);
        int right = Math.Clamp((rect.Right - 1) / tileSize, 0, cols - 1);
        int top = Math.Clamp(rect.Top / tileSize, 0, rows - 1);
        int bottom = Math.Clamp((rect.Bottom - 1) / tileSize, 0, rows - 1);
        for (int x = left; x <= right; x++)
        for (int y = top; y <= bottom; y++)
        {
            if (tiles[x, y].Type == TileType.Indestructible || tiles[x, y].Type == TileType.Destructible) return true;
        }
        return false;
    }

    void Restart()
    {
        // limpiar bombas/explosiones/enemigos y reposicionar jugador
        bombs.Clear();
        explosions.Clear();
        enemies.Clear();
        // rebuild destructible blocks randomly
        for (int x = 1; x < cols - 1; x++)
        for (int y = 1; y < rows - 1; y++)
        {
            if (tiles[x, y].Type == TileType.Indestructible) continue;
            bool nearSpawn = (x <= 2 && y <= 2);
            tiles[x, y].Type = (!nearSpawn && rnd.NextDouble() < 0.55) ? TileType.Destructible : TileType.Empty;
        }
        playerPosition = new Vector2(tileSize * 1 + (tileSize - playerSize) / 2, tileSize * 1 + (tileSize - playerSize) / 2);
        isDead = false; gameOver = false; deathFrame = 0; deathTimer = 0f; // keep score across rounds
        int baseEnemies = 3 + (level - 1) * 2;
        int spawnMinDist = 4; // min Manhattan distance from player spawn
        Point spawnCell = new Point(1,1);
        for (int i = 0; i < baseEnemies; i++)
        {
            Point c;
            int attempts = 0;
            do
            {
                c = new Point(rnd.Next(1, cols - 1), rnd.Next(1, rows - 1));
                attempts++;
            } while ((tiles[c.X, c.Y].Type != TileType.Empty || (c.X <= 2 && c.Y <= 2) || (Math.Abs(c.X - spawnCell.X) + Math.Abs(c.Y - spawnCell.Y) < spawnMinDist)) && attempts < 400);
            var en = new Enemy();
                en.Cell = c;
                en.Size = tileSize;
                en.Pos = new Vector2(c.X * tileSize + (tileSize - en.Size) / 2, c.Y * tileSize + (tileSize - en.Size) / 2);
            en.Dir = RandomDir();
            enemies.Add(en);
        }
        // elegir una nueva puerta oculta tras un bloque destructible
        var destructibles = new List<Point>();
        for (int x = 1; x < cols - 1; x++)
        for (int y = 1; y < rows - 1; y++)
            if (tiles[x, y].Type == TileType.Destructible && !(x <= 2 && y <= 2)) destructibles.Add(new Point(x, y));
        if (destructibles.Count > 0) doorCell = destructibles[rnd.Next(destructibles.Count)];
        else doorCell = new Point(Math.Min(3, cols-2), Math.Min(3, rows-2));
        doorRevealed = false;
    }

    void RequestExit(string reason)
    {
        try { Console.WriteLine($"RequestExit called: {reason} State={state} exitSuppressedTimer={exitSuppressedTimer}"); } catch { }
        try { LogToFile($"RequestExit called: {reason} State={state} exitSuppressedTimer={exitSuppressedTimer}"); } catch {}
        if (exitSuppressedTimer > 0f)
        {
            try { Console.WriteLine("Exit suppressed due to recent Victory transition."); } catch { }
            try { LogToFile("Exit suppressed due to recent Victory transition."); } catch {}
            return;
        }
        try { Console.WriteLine("Exit requested - exiting now."); } catch { }
        try { LogToFile("Exit requested - exiting now."); } catch {}
        try { Exit(); } catch (Exception ex) { try { LogToFile("Exit() threw: " + ex); } catch {} }
    }

    bool IsColliding(Vector2 candidatePos)
    {
        Rectangle playerRect = new Rectangle((int)candidatePos.X, (int)candidatePos.Y, playerSize, playerSize);
        int left = Math.Clamp(playerRect.Left / tileSize, 0, cols - 1);
        int right = Math.Clamp(playerRect.Right / tileSize, 0, cols - 1);
        int top = Math.Clamp(playerRect.Top / tileSize, 0, rows - 1);
        int bottom = Math.Clamp(playerRect.Bottom / tileSize, 0, rows - 1);

        for (int x = left; x <= right; x++)
        for (int y = top; y <= bottom; y++)
        {
            if (tiles[x, y].Type == TileType.Indestructible || tiles[x, y].Type == TileType.Destructible) return true;
        }
        // también colisionar con bombas estáticas (impide pasar sobre bomba)
        // Permitir salir de la celda donde está la bomba: ignoramos la bomba si el centro del jugador queda en la misma celda
        Point centerCell = new Point((playerRect.Center.X) / tileSize, (playerRect.Center.Y) / tileSize);
        foreach (var b in bombs)
        {
            // ignorar bombas en periodo de exención para permitir salir tras colocar
            if (b.ExemptTime > 0f) continue;
            // permitir salir si venimos de la celda de la bomba (previa) o si estamos aún en la misma celda
            if (b.Cell == centerCell) continue; // permitir paso si estamos en la misma celda (salir)
            if (previousPlayerCell == b.Cell) continue; // permitir salir si veníamos de la celda de la bomba
            Rectangle br = new Rectangle(b.Cell.X * tileSize + (tileSize-32)/2, b.Cell.Y * tileSize + (tileSize-32)/2, 32, 32);
            if (playerRect.Intersects(br)) return true;
        }
        return false;
    }

    Rectangle[] GetMainMenuRects()
    {
        int cx = GraphicsDevice.Viewport.Width / 2;
        int cy = GraphicsDevice.Viewport.Height / 2;
        int optW = 300; int optH = 48; int spacing = 56;
        var rects = new Rectangle[mainMenuOptions.Length];
        for (int i = 0; i < mainMenuOptions.Length; i++) rects[i] = new Rectangle(cx - optW/2, cy + i * spacing, optW, optH);
        return rects;
    }

    bool CanPlaceBomb()
    {
        // limite simple: maxBombs simultaneas
        if (bombs.Count >= maxBombs) return false;
        return true;
    }

    void PlaceBombAtPlayer()
    {
        Point cell = new Point((int)(playerPosition.X + playerSize/2) / tileSize, (int)(playerPosition.Y + playerSize/2) / tileSize);
        // no apilar bombas en misma celda
        if (bombs.Exists(b => b.Cell == cell)) return;
        bombs.Add(new Bomb { Cell = cell, Timer = 2.0f, Range = 3, Texture = bombTexture, ExemptTime = 0.45f });
    }

    void Explode(Bomb bomb)
    {
        var explosion = new Explosion();
        explosion.Origin = bomb.Cell;
        // centro
        explosion.Cells.Add(bomb.Cell);

        // cuatro direcciones
        var dirs = new Point[] { new Point(1,0), new Point(-1,0), new Point(0,1), new Point(0,-1) };
        foreach (var d in dirs)
        {
            for (int r = 1; r <= bomb.Range; r++)
            {
                int nx = bomb.Cell.X + d.X * r;
                int ny = bomb.Cell.Y + d.Y * r;
                if (nx < 0 || nx >= cols || ny < 0 || ny >= rows) break;
                if (tiles[nx, ny].Type == TileType.Indestructible) break;
                explosion.Cells.Add(new Point(nx, ny));
                if (tiles[nx, ny].Type == TileType.Destructible)
                {
                    // destruir bloque
                    tiles[nx, ny].Type = TileType.Empty;
                    score += 10;
                    // si destruimos el ladrillo que ocultaba la puerta, revelarla
                    if (nx == doorCell.X && ny == doorCell.Y) doorRevealed = true;
                    break; // la explosión se detiene tras destruir
                }
            }
        }

        explosions.Add(explosion);

        // play explosion SFX if available, otherwise play fallback explosion Song briefly
        if (explosionSfx != null)
        {
            try { explosionSfx.Play(masterVolume, 0f, 0f); } catch { }
        }
        else if (explosionSong != null)
        {
            // pause/replace current song briefly and resume after a short timer
            pendingResumeSong = currentSong;
            try { MediaPlayer.Play(explosionSong); currentSong = explosionSong; } catch { }
            explosionSongTimer = 0.9f; // play ~0.9s then resume
            MediaPlayer.Volume = masterVolume;
        }

        // Chequear si el jugador está en alguna celda de la explosión -> muerte (animación/vidas)
        Point playerCell = new Point((int)(playerPosition.X + playerSize/2) / tileSize, (int)(playerPosition.Y + playerSize/2) / tileSize);
        foreach (var c in explosion.Cells) if (c == playerCell)
        {
            isDead = true;
            deathFrame = 0;
            deathTimer = 0f;
            lives = Math.Max(0, lives - 1);
            // quitar puntos por muerte
            score = Math.Max(0, score - 50);
            break;
        }
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.Black);

        _spriteBatch.Begin(SpriteSortMode.Deferred, BlendState.AlphaBlend, SamplerState.PointClamp, null, null);
        Texture2D px = new Texture2D(GraphicsDevice, 1, 1);
        px.SetData(new[] { Color.White });

            // Menú principal (procedural)
            if (state == GameState.MainMenu)
            {
                // background (blue)
                _spriteBatch.Draw(px, new Rectangle(0,0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), Color.CornflowerBlue);

                // title (uppercase, orange)
                string title = "BOMBERBUILD";
                var titleMeasure = menuFont.MeasureString(title);
                float titleScale = 2.4f;
                Vector2 titlePos = new Vector2((GraphicsDevice.Viewport.Width - titleMeasure.X * titleScale) / 2f, GraphicsDevice.Viewport.Height * 0.22f);
                _spriteBatch.DrawString(menuFont, title, titlePos + new Vector2(3,3), Color.Black * 0.6f, 0f, Vector2.Zero, titleScale, SpriteEffects.None, 0f);
                _spriteBatch.DrawString(menuFont, title, titlePos, Color.Orange, 0f, Vector2.Zero, titleScale, SpriteEffects.None, 0f);

                // options
                int cx = GraphicsDevice.Viewport.Width / 2;
                int cy = GraphicsDevice.Viewport.Height / 2;
                int spacing = 56;
                for (int i = 0; i < mainMenuOptions.Length; i++)
                {
                    string txt = mainMenuOptions[i];
                    var measure = menuFont.MeasureString(txt);
                    float scale = (i == menuIndex) ? 1.2f : 1.0f;
                    Color col = (i == menuIndex) ? Color.Gold : Color.Black;
                    Vector2 pos = new Vector2(cx - (measure.X * scale) / 2f, cy + i * spacing - (measure.Y * scale) / 2f);
                    _spriteBatch.DrawString(menuFont, txt, pos + new Vector2(2,2), Color.Black * 0.6f, 0f, Vector2.Zero, scale, SpriteEffects.None, 0f);
                    _spriteBatch.DrawString(menuFont, txt, pos, col, 0f, Vector2.Zero, scale, SpriteEffects.None, 0f);
                }

                // optional hotspot overlay for alignment (toggle F1)
                if (showMenuHotspots)
                {
                    var rects = GetMainMenuRects();
                    foreach (var r in rects) _spriteBatch.Draw(px, r, Color.Yellow * 0.35f);
                }

                _spriteBatch.End();
                base.Draw(gameTime);
                return;
            }

        // Pantalla GameOver (procedural)
        if (state == GameState.GameOver)
        {
            // background
            _spriteBatch.Draw(px, new Rectangle(0,0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), Color.DarkGray);

            // big red PERDISTE
            string lost = "PERDISTE";
            var lostMeasure = menuFont.MeasureString(lost);
            float lostScale = 2.8f;
            Vector2 lostPos = new Vector2((GraphicsDevice.Viewport.Width - lostMeasure.X * lostScale)/2f, GraphicsDevice.Viewport.Height * 0.20f);
            _spriteBatch.DrawString(menuFont, lost, lostPos + new Vector2(4,4), Color.Black * 0.6f, 0f, Vector2.Zero, lostScale, SpriteEffects.None, 0f);
            _spriteBatch.DrawString(menuFont, lost, lostPos, Color.Red, 0f, Vector2.Zero, lostScale, SpriteEffects.None, 0f);

            // options
            int cx = GraphicsDevice.Viewport.Width / 2;
            int cy = GraphicsDevice.Viewport.Height / 2;
            int spacing = 56;
            for (int i = 0; i < gameOverOptions.Length; i++)
            {
                string txt = gameOverOptions[i];
                var measure = menuFont.MeasureString(txt);
                float scale = (i == menuIndex) ? 1.2f : 1.0f;
                Color col = (i == menuIndex) ? Color.Gold : Color.White;
                Vector2 pos = new Vector2(cx - (measure.X * scale) / 2f, cy + i * spacing - (measure.Y * scale) / 2f + 40);
                _spriteBatch.DrawString(menuFont, txt, pos + new Vector2(2,2), Color.Black * 0.6f, 0f, Vector2.Zero, scale, SpriteEffects.None, 0f);
                _spriteBatch.DrawString(menuFont, txt, pos, col, 0f, Vector2.Zero, scale, SpriteEffects.None, 0f);
            }

            _spriteBatch.End();
            base.Draw(gameTime);
            return;
        }

        // Pantalla Victory (procedural)
        if (state == GameState.Victory)
        {
            // background: use victory image if available, otherwise green
            if (victoryBgTexture != null)
            {
                _spriteBatch.Draw(victoryBgTexture, new Rectangle(0,0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), Color.White);
            }
            else
            {
                _spriteBatch.Draw(px, new Rectangle(0,0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), Color.ForestGreen);
            }

            // big green title
            string win = "GANASTE";
            var winMeasure = menuFont.MeasureString(win);
            float winScale = 3.0f;
            Vector2 winPos = new Vector2((GraphicsDevice.Viewport.Width - winMeasure.X * winScale)/2f, GraphicsDevice.Viewport.Height * 0.14f);
            _spriteBatch.DrawString(menuFont, win, winPos + new Vector2(4,4), Color.Black * 0.6f, 0f, Vector2.Zero, winScale, SpriteEffects.None, 0f);
            _spriteBatch.DrawString(menuFont, win, winPos, Color.LimeGreen, 0f, Vector2.Zero, winScale, SpriteEffects.None, 0f);

            // show score (prominent)
            string pts = $"Puntuación total: {score}";
            var ptsMeasure = menuFont.MeasureString(pts);
            Vector2 ptsPos = new Vector2((GraphicsDevice.Viewport.Width - ptsMeasure.X)/2f, winPos.Y + winMeasure.Y * winScale + 22);
            _spriteBatch.DrawString(menuFont, pts, ptsPos + new Vector2(2,2), Color.Black * 0.6f);
            _spriteBatch.DrawString(menuFont, pts, ptsPos, Color.White, 0f, Vector2.Zero, 1.0f, SpriteEffects.None, 0f);

            // options
            int cx = GraphicsDevice.Viewport.Width / 2;
            int cy = GraphicsDevice.Viewport.Height / 2;
            int spacing = 64;
            for (int i = 0; i < victoryOptions.Length; i++)
            {
                string txt = victoryOptions[i];
                var measure = menuFont.MeasureString(txt);
                float scale = (i == menuIndex) ? 1.2f : 1.0f;
                Color col = (i == menuIndex) ? Color.Black : Color.DarkSlateGray;
                Vector2 pos = new Vector2(cx - (measure.X * scale) / 2f, cy + i * spacing - (measure.Y * scale) / 2f + 40);
                _spriteBatch.DrawString(menuFont, txt, pos + new Vector2(2,2), Color.Black * 0.6f, 0f, Vector2.Zero, scale, SpriteEffects.None, 0f);
                _spriteBatch.DrawString(menuFont, txt, pos, col, 0f, Vector2.Zero, scale, SpriteEffects.None, 0f);
            }

            _spriteBatch.End();
            base.Draw(gameTime);
            return;
        }

        // Menú de Configuración (panel con control de volumen)
        if (state == GameState.ConfigMenu)
        {
            // darken background
            _spriteBatch.Draw(px, new Rectangle(0,0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), Color.Black * 0.6f);
            // panel
            int pw = 560; int ph = 300; int pxpos = (GraphicsDevice.Viewport.Width - pw)/2; int pypos = (GraphicsDevice.Viewport.Height - ph)/2;
            _spriteBatch.Draw(px, new Rectangle(pxpos, pypos, pw, ph), Color.DimGray * 0.95f);

            int panelCx = GraphicsDevice.Viewport.Width / 2;
            int panelCy = GraphicsDevice.Viewport.Height / 2;

            // Draw volume slider
            string volLabel = "Volumen";
            var volMeasure = menuFont.MeasureString(volLabel);
            Vector2 volPos = new Vector2(panelCx - volMeasure.X/2f, panelCy - 84);
            _spriteBatch.DrawString(menuFont, volLabel, volPos + new Vector2(2,2), Color.Black * 0.6f, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0f);
            _spriteBatch.DrawString(menuFont, volLabel, volPos, Color.WhiteSmoke, 0f, Vector2.Zero, 1f, SpriteEffects.None, 0f);

            Rectangle sliderRect = new Rectangle(panelCx - 160, panelCy - 40, 320, 20);
            _spriteBatch.Draw(px, sliderRect, Color.DarkGray);
            // filled portion
            Rectangle filled = new Rectangle(sliderRect.Left, sliderRect.Top, (int)(sliderRect.Width * masterVolume), sliderRect.Height);
            _spriteBatch.Draw(px, filled, Color.Orange);
            // knob
            int knobX = sliderRect.Left + (int)(masterVolume * (sliderRect.Width));
            Rectangle knobRect = new Rectangle(knobX - 8, sliderRect.Top - 6, 16, sliderRect.Height + 12);
            _spriteBatch.Draw(px, knobRect, Color.White);
            // percent text
            string pct = (int)(masterVolume * 100) + "%";
            var pctMeasure = menuFont.MeasureString(pct);
            Vector2 pctPos = new Vector2(panelCx - pctMeasure.X/2f, sliderRect.Bottom + 6);
            _spriteBatch.DrawString(menuFont, pct, pctPos, Color.White);

            // options below slider
            string[] cfgOptions = new[] { "Volumen", "Volver", "Salir" };
            int spacing = 56;
            for (int i = 1; i < cfgOptions.Length; i++)
            {
                string txt = cfgOptions[i];
                var measure = menuFont.MeasureString(txt);
                float scale = (i == menuIndex) ? 1.15f : 1.0f;
                Color col = (i == menuIndex) ? Color.Gold : Color.LightGray;
                Vector2 pos = new Vector2(panelCx - (measure.X * scale) / 2f, panelCy + (i-1) * spacing + 20);
                _spriteBatch.DrawString(menuFont, txt, pos + new Vector2(2,2), Color.Black * 0.6f, 0f, Vector2.Zero, scale, SpriteEffects.None, 0f);
                _spriteBatch.DrawString(menuFont, txt, pos, col, 0f, Vector2.Zero, scale, SpriteEffects.None, 0f);
            }

            _spriteBatch.End();
            base.Draw(gameTime);
            return;
        }

        // Dibujar tiles (paredes/bloques) como rectángulos simples

        for (int x = 0; x < cols; x++)
        for (int y = 0; y < rows; y++)
        {
            var t = tiles[x, y];
            if (t.Type == TileType.Indestructible)
                _spriteBatch.Draw(px, t.Bounds, Color.DarkGray);
            else if (t.Type == TileType.Destructible)
            {
                if (brickTexture != null)
                {
                    // stretch the brick texture to fill the full tile cell using full source rect
                    var src = new Rectangle(0, 0, brickTexture.Width, brickTexture.Height);
                    _spriteBatch.Draw(brickTexture, t.Bounds, src, Color.White);
                }
                else
                {
                    _spriteBatch.Draw(px, t.Bounds, Color.SaddleBrown);
                }
            }
        }

        // Dibujar bombas
        foreach (var b in bombs)
        {
            Vector2 pos = new Vector2(b.Cell.X * tileSize + (tileSize - 32) / 2, b.Cell.Y * tileSize + (tileSize - 32) / 2);
            _spriteBatch.Draw(b.Texture, pos, Color.White);
        }

        // Dibujar explosiones (usar sprites si están disponibles)
        foreach (var e in explosions)
        {
            foreach (var c in e.Cells)
            {
                Rectangle r = new Rectangle(c.X * tileSize, c.Y * tileSize, tileSize, tileSize);
                // center
                if (c == e.Origin)
                {
                    if (explosionTexture != null) _spriteBatch.Draw(explosionTexture, r, Color.White);
                    else _spriteBatch.Draw(px, r, Color.OrangeRed * 0.85f);
                }
                else
                {
                    // horizontal if same Y as origin, vertical if same X
                    if (c.Y == e.Origin.Y)
                    {
                        if (explosionHorizontalTexture != null) _spriteBatch.Draw(explosionHorizontalTexture, r, Color.White);
                        else _spriteBatch.Draw(px, r, Color.OrangeRed * 0.85f);
                    }
                    else
                    {
                        if (explosionVerticalTexture != null) _spriteBatch.Draw(explosionVerticalTexture, r, Color.White);
                        else _spriteBatch.Draw(px, r, Color.OrangeRed * 0.85f);
                    }
                }
            }
        }

        // Dibujar enemigos
        foreach (var en in enemies)
        {
            _spriteBatch.Draw(enemyTexture, new Rectangle((int)en.Pos.X, (int)en.Pos.Y, en.Size, en.Size), Color.White);
        }

        // Dibujar animaciones de muerte de enemigos
        foreach (var ed in enemyDeaths)
        {
            int f = Math.Clamp(ed.Frame, 0, enemyDeathTextures.Length - 1);
            _spriteBatch.Draw(enemyDeathTextures[f], new Rectangle((int)ed.Pos.X, (int)ed.Pos.Y, tileSize, tileSize), Color.White);
        }

        // Dibujar puerta si fue revelada (o si el ladrillo ya fue removido)
        if (doorRevealed)
        {
            Rectangle dr = new Rectangle(doorCell.X * tileSize, doorCell.Y * tileSize, tileSize, tileSize);
            _spriteBatch.Draw(doorTexture, dr, Color.White);
        }

        // Dibujar corazones según vidas (arriba izquierda)
        Texture2D hearts = null;
        if (lives >= 3) hearts = hearts3;
        else if (lives == 2) hearts = hearts2;
        else if (lives == 1) hearts = hearts1;
        if (hearts != null)
        {
            _spriteBatch.Draw(hearts, new Rectangle(8,8, hearts.Width, hearts.Height), Color.White);
        }
        // show score a bit arriba a la derecha of hearts
        string scoreText = $"Puntos: {score}";
        var scoreMeasure = menuFont.MeasureString(scoreText);
        float scoreX = 8 + (hearts != null ? hearts.Width + 18 : 8);
        float scoreY = 6f; // slightly higher to avoid touching map
        _spriteBatch.DrawString(menuFont, scoreText, new Vector2(scoreX, scoreY), Color.White);

        // Dibujar jugador (animaciones segun estado)
        Rectangle playerRect = new Rectangle((int)playerPosition.X, (int)playerPosition.Y, playerSize, playerSize);
        if (isDead || gameOver)
        {
            int idx = Math.Min(deathFrame, deathTextures.Length - 1);
            _spriteBatch.Draw(deathTextures[idx], playerRect, Color.White);
        }
        else
        {
            Texture2D tex = playerTexture;
            SpriteEffects fx = SpriteEffects.None;
            if (lastMoveDirection.LengthSquared() > 0)
            {
                if (lastMoveDirection.Y < 0) tex = walkBack;
                else if (lastMoveDirection.Y > 0) tex = walkFront;
                else // horizontal
                {
                    tex = walkProfile;
                    // flip corrected: flip when moving right if sprite faces left by default
                    if (lastMoveDirection.X > 0) fx = SpriteEffects.FlipHorizontally;
                }
            }
            _spriteBatch.Draw(tex, playerRect, null, Color.White, 0f, Vector2.Zero, fx, 0f);
        }

            // Pausa overlay
            if (state == GameState.Playing && isPaused)
            {
                // semi-transparent overlay
                _spriteBatch.Draw(px, new Rectangle(0,0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height), Color.Black * 0.5f);
                string pauseText = "PAUSA";
                var pm = menuFont.MeasureString(pauseText);
                float pscale = 2.2f;
                Vector2 ppos = new Vector2((GraphicsDevice.Viewport.Width - pm.X * pscale)/2f, GraphicsDevice.Viewport.Height * 0.4f);
                _spriteBatch.DrawString(menuFont, pauseText, ppos + new Vector2(3,3), Color.Black * 0.6f, 0f, Vector2.Zero, pscale, SpriteEffects.None, 0f);
                _spriteBatch.DrawString(menuFont, pauseText, ppos, Color.WhiteSmoke, 0f, Vector2.Zero, pscale, SpriteEffects.None, 0f);
            }

            _spriteBatch.End();

        base.Draw(gameTime);
    }
}

﻿using System;

try
{
	using var game = new Bomberman.Game1();
	game.Run();
}
catch (Exception ex)
{
	try { Console.WriteLine($"Unhandled exception: {ex}"); } catch { }
	throw;
}
try
{
	using var game = new Bomberman.Game1();
	game.Run();
}
catch (Exception ex)
{
	try { Console.WriteLine($"Unhandled exception: {ex}"); } catch { }
	throw;
}
